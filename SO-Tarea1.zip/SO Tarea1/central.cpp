#include <bits/stdc++.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
using namespace std;

struct Cliente {
    int pid;
    int fd_in;
    int fd_out;
    string fifo_in;
    string fifo_out;
};

int main() {
    const string fifo_registro = "/tmp/chat_registro";
    const string fifo_reportes = "/tmp/chat_reportes";

    mkfifo(fifo_registro.c_str(), 0666);
    mkfifo(fifo_reportes.c_str(), 0666);

    pid_t pid_rep = fork();
    if (pid_rep == 0) {
        execlp("./reportes", "./reportes", fifo_reportes.c_str(), nullptr);
        perror("execlp reportes");
        _exit(1);
    }

    int fd_reg = open(fifo_registro.c_str(), O_RDONLY | O_NONBLOCK);
    if (fd_reg < 0) { perror("open registro"); return 1; }

    int fd_rep = open(fifo_reportes.c_str(), O_WRONLY);
    if (fd_rep < 0) { perror("open fifo_reportes (central)"); /*seguir*/ }

    vector<Cliente> clientes;
    char buf[512];

    FILE *logf = fopen(logfile.c_str(), "a");
    if (!logf) { perror("fopen log"); }

    cout << "Central: Iniciado \n";

    while (true) {
        ssize_t n = read(fd_reg, buf, sizeof(buf)-1);
        if (n > 0) {
            buf[n] = '\0';
            int pid;
            char fin[160], fout[160];
            if (sscanf(buf, "%d %159s %159s", &pid, fin, fout) == 3) {
                Cliente c;
                c.pid = pid;
                c.fifo_in = fin;
                c.fifo_out = fout;
                c.fd_in  = open(c.fifo_in.c_str(), O_RDONLY | O_NONBLOCK);
                c.fd_out = open(c.fifo_out.c_str(), O_WRONLY | O_NONBLOCK);
                if (c.fd_in < 0 || c.fd_out < 0) {
                    perror("open cliente fifo");
                    if (c.fd_in >= 0) close(c.fd_in);
                    if (c.fd_out >= 0) close(c.fd_out);
                } else {
                    clientes.push_back(c);
                    cout << "Central: Cliente " << pid << " conectado\n";
                }
            }
        }

        for (auto it = clientes.begin(); it != clientes.end();) {
            memset(buf, 0, sizeof(buf));
            ssize_t m = read(it->fd_in, buf, sizeof(buf)-1);
            if (m > 0) {
                buf[m] = '\0';
                time_t t = time(nullptr);
                char ts[32];
                strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", localtime(&t));
                if (logf) fprintf(logf, "[%s] %d: %s\n", ts, it->pid, buf);
                fflush(logf);

                cout << "Central: (" << it->pid << "): " << buf;

                if (strncmp(buf, "reportar ", 9) == 0) {
                    write(fd_rep, buf, strlen(buf));
                } else {
                    for (auto &o : clientes) {
                        if (o.pid == it->pid) continue;
                        write(o.fd_out, buf, strlen(buf));
                    }
                }
                ++it;
            } else if (m == 0) {
                cout << "Central: Cliente " << it->pid << " desconectado\n";
                close(it->fd_in);
                close(it->fd_out);
                it = clientes.erase(it);
            } else {
                ++it;
            }
        }
    }
}

