#include <bits/stdc++.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
using namespace std;

int main() {
    pid_t pid = getpid();
    string fifo_reg = "/tmp/chat_registro";
    string fin = "/tmp/cliente_" + to_string(pid) + "_in";
    string fout= "/tmp/cliente_" + to_string(pid) + "_out";

    mkfifo(fin.c_str(), 0666);
    mkfifo(fout.c_str(), 0666);

    int fd_reg = open(fifo_reg.c_str(), O_WRONLY);
    if (fd_reg < 0) { perror("open registro (cliente)"); return 1; }
    string regmsg = to_string(pid) + " " + fin + " " + fout;
    write(fd_reg, regmsg.c_str(), regmsg.size());
    close(fd_reg);

    int fd_in = open(fout.c_str(), O_RDONLY | O_NONBLOCK);
    int fd_out = open(fin.c_str(), O_WRONLY);
    if (fd_in < 0 || fd_out < 0) { perror("open cliente fds"); return 1; }

    cout << "Cliente numero " << pid << " escribe 'duplicar' para clonar\n";

    pid_t child = fork();
    if (child == 0) {
        char b[512];
        while (true) {
            ssize_t n = read(fd_in, b, sizeof(b)-1);
            if (n > 0) {
                b[n] = '\0';
                cout << " otro cliente " << b;
            }
            usleep(100000);
        }
        return 0;
    } else {
        string line;
        while (true) {
            if (!getline(cin, line)) break;
            if (line == "salir") {
                close(fd_in); close(fd_out);
                unlink(fin.c_str()); unlink(fout.c_str());
                kill(child, SIGTERM);
                break;
            } else if (line == "duplicar") {
                pid_t p = fork();
                if (p == 0) {
                    execlp("./cliente", "./cliente", nullptr);
                    perror("execlp duplicar");
                    _exit(1);
                } else {
                    cout << "Cliente: Se creó duplicado con pid " << p << "\n";
                }
            } else {
                write(fd_out, (line + "\n").c_str(), line.size()+1);
            }
        }
    }
    return 0;
}
