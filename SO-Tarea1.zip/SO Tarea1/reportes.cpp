#include <bits/stdc++.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <csignal>
using namespace std;

int main(int argc, char** argv) {
    if (argc < 2) {
        cerr << "Uso: reportes <fifo_reportes>\n";
        return 1;
    }
    string fifo_reportes = argv[1];
    int fd = open(fifo_reportes.c_str(), O_RDONLY);
    if (fd < 0) {
        perror("open reportes");
        return 1;
    }
    map<int,int> m;
    char buf[256];

    cout << "Reportes:\n";

    while (true) {
        ssize_t n = read(fd, buf, sizeof(buf)-1);
        if (n > 0) {
            buf[n] = '\0';
            buf[strcspn(buf, "\n")] = '\0';
            buf[strcspn(buf, "\r")] = '\0';

            int pid;
            if (sscanf(buf, "reportar %d", &pid) == 1) {
                m[pid]++;
                cout << "Reportes: pid " << pid << " -> " << m[pid] << " reportes\n";

                if (m[pid] > 10) {
                    cout << "Reportes: Excedido 10 -> matando " << pid << "\n";
                    kill(pid, SIGKILL);
                }
            }
        } else if (n == 0) {
            cout << "Reportes: Central cerró el pipe. Terminando...\n";
            break;
        } else {
        }
    }
    close(fd);
    return 0;
}
