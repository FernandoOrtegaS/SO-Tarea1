#include <iostream>
#include <unistd.h>
#include <signal.h>
using namespace std;

int main(){
    int pid,cont[50]={0};
    cout<<"Reportes listo\n";
    string cmd;
    while(cin>>cmd>>pid){
        if(cmd=="reportar"){
            cont[pid%50]++;
            cout<<"Reporte a "<<pid<<" ("<<cont[pid%50]<<")\n";
            if(cont[pid%50]>10){
                kill(pid,SIGKILL);
                cout<<"Proceso "<<pid<<" eliminado\n";
            }
        }
    }
}
