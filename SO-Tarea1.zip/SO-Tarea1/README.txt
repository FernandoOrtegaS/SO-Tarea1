compilar:
g++ central.cpp -o central
g++ reportes.cpp -o reportes
g++ cliente.cpp -o cliente

ejecrtar:
  1.en una terminal:
       ./central
  2.en otras terminales:
       ./cliente

comandos:
  ° duplicar : crea un nuevo cliente
  ° reportar <pid>: envía reporte contra ese pid
  ° exit: para salir del cliente

como funciona:
  ° central recibe todos los mensajes y los reenvía a todos.
  ° el módulo reportes cuenta reportes por pid. 
  ° si un cliente supera 10 reportes, se le hace kill.
  ° se comunican con named pipes (FIFOs).

