#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <string.h>
using namespace std;

#define MAXC 10

int main() {
    mkfifo("/tmp/central_reg", 0666);
    int regfd = open("/tmp/central_reg", O_RDONLY | O_NONBLOCK);
    int c2s[MAXC], s2c[MAXC], pids[MAXC];
    int ncli = 0;

    int p[2]; pipe(p);
    if (fork() == 0) {
        dup2(p[0],0); close(p[0]); close(p[1]);
        execl("./reportes","./reportes",NULL);
    }
    close(p[0]);

    cout << "Central iniciado\n";

    while (1) {
        char buf[128];
        int n = read(regfd, buf, 127);
        if (n > 0) {
            buf[n]=0;
            int pid = atoi(buf+9); // REGISTER <pid>
            char f1[64], f2[64];
            sprintf(f1,"/tmp/c2s_%d",pid);
            sprintf(f2,"/tmp/s2c_%d",pid);
            mkfifo(f1,0666); mkfifo(f2,0666);
            c2s[ncli]=open(f1,O_RDONLY|O_NONBLOCK);
            s2c[ncli]=open(f2,O_WRONLY);
            pids[ncli]=pid;
            cout<<"Conectado "<<pid<<"\n";
            ncli++;
        }
        for(int i=0;i<ncli;i++){
            int m=read(c2s[i],buf,127);
            if(m>0){
                buf[m]=0;
                cout<<"["<<pids[i]<<"] "<<buf;
                if(strncmp(buf,"reportar",8)==0)
                    write(p[1],buf,strlen(buf));
                for(int j=0;j<ncli;j++)
                    write(s2c[j],buf,strlen(buf));
            }
        }
        usleep(100000);
    }
}
