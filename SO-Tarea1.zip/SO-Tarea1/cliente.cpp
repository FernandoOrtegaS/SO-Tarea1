#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
using namespace std;

int main(){
    int pid=getpid();
    char f1[64],f2[64];
    sprintf(f1,"/tmp/c2s_%d",pid);
    sprintf(f2,"/tmp/s2c_%d",pid);
    mkfifo(f1,0666); mkfifo(f2,0666);

    int reg=open("/tmp/central_reg",O_WRONLY);
    char msg[64]; sprintf(msg,"REGISTER %d\n",pid);
    write(reg,msg,strlen(msg)); close(reg);

    int fd1=open(f1,O_WRONLY);
    int fd2=open(f2,O_RDONLY|O_NONBLOCK);

    cout<<"Cliente "<<pid<<" conectado\n";

    char buf[128];
    while(1){
        fd_set fds; FD_ZERO(&fds);
        FD_SET(0,&fds); FD_SET(fd2,&fds);
        int m=(fd2>0?fd2:0);
        select(m+1,&fds,0,0,0);

        if(FD_ISSET(0,&fds)){
            int n=read(0,buf,127);
            if(n<=0) break;
            buf[n]=0;
            if(strncmp(buf,"duplicar",3)==0){
                if(fork()==0) execl("./cliente","./cliente",NULL);
            }
            write(fd1,buf,strlen(buf));
            if(strncmp(buf,"salir",4)==0) break;
        }
        if(FD_ISSET(fd2,&fds)){
            int n=read(fd2,buf,127);
            if(n>0){ buf[n]=0; cout<<buf; }
        }
    }
    close(fd1); close(fd2);
    unlink(f1); unlink(f2);
}
